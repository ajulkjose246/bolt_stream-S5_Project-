<?php
session_start();
error_reporting(E_ERROR | E_PARSE);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Bolt Stream</title>
  <!-- CSS only -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <link href="css/style.css" rel="stylesheet">
 
</head>
<?php
$user_type = $_SESSION['user_type'];
if ($user_type==1) {
?>
<body>
  <section>
    <div class="container">

    <table class="table my-5 table-dark">
        <tr>
          <th>User Id</th>
          <th>First Name</th>
          <th>Second Name</th>
          <th>Email</th>
          <th>Username</th>
          <th>User Type</th>
          <th>Action</th>
        </tr>
        <?php
        $con = mysqli_connect("localhost","root","","db_bolt_stream");
        $mysql ="SELECT * FROM `tbl_usr_details`";
        $result = mysqli_query($con,$mysql);
        while($row=mysqli_fetch_array($result)){
            ?>
                <tr>
                    <td><?=$row['usr_id']?></td>
                    <td><?=$row['usr_fname']?></td>
                    <td><?=$row['usr_lname']?></td>
                    <td><?=$row['usr_email']?></td>
                    <td><?=$row['usr_username']?></td>
                    <td><?=$row['usr_type']?></td>
                    <td><a href="./secure/delete_data.php?id=<?=$row['usr_id']?>" class="btn btn-danger">Delete</a>
                    <a href="./secure/update_data.php?id=<?=$row['usr_id']?>" class="btn btn-primary">Update</a></td>
                </tr>
            <?php
        }
    ?>
      </table>
    </div> 
    <div class="d-flex justify-content-center ">
    <a class="btn btn-success" href="./user_profile.php">Back</a>
    </div>
  </section>

    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/main.js"></script>
</body>
<?php
$user_id = $_SESSION['usr_id'];
if ($user_id > 0) {
  echo ("<script>$('.log-btn').hide()</script>");

  $con = mysqli_connect("localhost", "root", "", "db_bolt_stream") or die("Connection error");
  $query1 = "SELECT * FROM `tbl_usr_details` WHERE usr_id = '$user_id'";
  $result = mysqli_query($con, $query1);
  $row = mysqli_fetch_array($result);
  $_SESSION['user_type'] = $row['usr_type'];
  $pro_name = $row['usr_fname'] . ' ' . $row['usr_lname'];
  $pro_pic = $row['usr_pic'];
  $username = $row['usr_username'];

  echo ("<script>$('.usr_pro_pic').attr('src','./pro_pic/$pro_pic');</script>");
  echo ("<script>$('.user_name').text('$pro_name');</script>");
  echo ("<script>$('.username').text('@$username');</script>");
  if (isset($_POST['log_out'])) {
    session_destroy();
    unset($_SESSION['usr_id']);
    $url = "index.php";
    echo ("<script>location.href='$url'</script>");
  }
} else {
  echo ("<script>$('.profile-menu').hide()</script>");
}

// set movie id in section
}else{
    echo("<script>location.href='index.php'</script>");

}
?>

</html>